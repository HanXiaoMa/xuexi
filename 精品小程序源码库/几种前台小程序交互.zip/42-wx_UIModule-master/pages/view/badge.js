// pages/view/badge.js
Page({
  data: {
    dataSource: [0, 9, 99, 999]
  },
  onLoad: function (options) {

  },
  onShow: function () {

  },

})