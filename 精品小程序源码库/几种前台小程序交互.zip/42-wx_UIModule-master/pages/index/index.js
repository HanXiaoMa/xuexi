Page({
  data: {
    itemData: ['上拉菜单', '背景幕', '条形码', '浮动按钮', '日历', '倒计时', '计数器', '对话框', '画廊', '指示器', '通知', '选择器', '提示消息', '二维码', '评分', '下拉刷新', '座位图', '提示框', '顶部提示', '数字输入框', '角标', '按钮', '卡片', 'cell', '弹出框', 'form表单', 'label', '加载更多', '加减控件', '步骤', '开关', 'tab', 'toast', 'toptips'],

    dataSource: [{ 'name': '底部弹出视图-Dialog', 'path': '/pages/view/Dialog' }, { 'name': '支付密码输入框-PassWordInput', 'path': '/pages/view/pwdInput' }, { 'name': '商品数量加减-Quantity', 'path': '/pages/view/numberPlusMinus' }, { 'name': '提示消息-Toast', 'path': '/pages/view/messageView' }, { 'name': '顶部提示-Toptip', 'path': '/pages/view/topMessage' }, { 'name': '角标-Badge', 'path': '/pages/view/badge' }]
  },
  onLoad: function (options) {
    
  },
  onReady: function () {
    
  },
  onShow: function () {
    
  },
  onHide: function () {
    
  },
  onUnload: function () {
    
  },
  onPullDownRefresh: function () {
    
  },
  onReachBottom: function () {
    
  },
  onShareAppMessage: function () {
    
  }
})